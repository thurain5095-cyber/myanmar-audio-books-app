package com.example.myanmar_audio_books

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
