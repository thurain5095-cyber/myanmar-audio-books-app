import 'dart:typed_data';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'encryption_service.dart';
import '../models/models.dart';

class EncryptedAudioSource extends StreamAudioSource {
  final Uint8List bytes;
  EncryptedAudioSource(this.bytes);

  @override
  Future<StreamAudioResponse> request([int? start, int? end]) async {
    start ??= 0;
    end ??= bytes.length;
    return StreamAudioResponse(
      sourceLength: bytes.length,
      contentLength: end - start,
      offset: start,
      stream: Stream.value(bytes.sublist(start, end)),
      contentType: 'audio/mpeg',
    );
  }
}

class AudioPlayerService {
  final AudioPlayer _player = AudioPlayer();
  final EncryptionService _encryptionService = EncryptionService();

  AudioPlayer get player => _player;

  Future<void> playBook(Book book, {bool isOffline = false}) async {
    if (isOffline && book.localPath != null) {
      final decryptedBytes = await _encryptionService.decryptFile(book.localPath!);
      await _player.setAudioSource(
        EncryptedAudioSource(decryptedBytes),
        tag: MediaItem(
          id: book.id,
          title: book.title,
          artist: book.authorName,
          artUri: book.coverUrl != null ? Uri.parse(book.coverUrl!) : null,
        ),
      );
    } else {
      await _player.setAudioSource(
        AudioSource.uri(
          Uri.parse(book.audioUrl),
          tag: MediaItem(
            id: book.id,
            title: book.title,
            artist: book.authorName,
            artUri: book.coverUrl != null ? Uri.parse(book.coverUrl!) : null,
          ),
        ),
      );
    }
    _player.play();
  }

  void seek(Duration position) => _player.seek(position);
  void setSpeed(double speed) => _player.setSpeed(speed);
  void stop() => _player.stop();
  void dispose() => _player.dispose();
}
