import 'dart:io';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import 'encryption_service.dart';
import '../models/models.dart';

class DownloadService {
  final Dio _dio = Dio();
  final EncryptionService _encryptionService = EncryptionService();

  Future<String?> downloadAndEncrypt(Book book, Function(double) onProgress) async {
    try {
      final dir = await getApplicationDocumentsDirectory();
      final tempPath = '${dir.path}/${book.id}_temp.mp3';
      final finalPath = '${dir.path}/${book.id}.dat';

      await _dio.download(
        book.audioUrl,
        tempPath,
        onReceiveProgress: (received, total) {
          if (total != -1) {
            onProgress(received / total);
          }
        },
      );

      await _encryptionService.encryptFile(tempPath, finalPath);
      return finalPath;
    } catch (e) {
      print('Download error: \$e');
      return null;
    }
  }

  Future<bool> isDownloaded(String bookId) async {
    final dir = await getApplicationDocumentsDirectory();
    return File('${dir.path}/\$bookId.dat').exists();
  }

  Future<void> deleteDownload(String bookId) async {
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/\$bookId.dat');
    if (await file.exists()) {
      await file.delete();
    }
  }
}
