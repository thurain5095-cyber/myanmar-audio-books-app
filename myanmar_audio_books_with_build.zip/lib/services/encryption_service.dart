import 'dart:io';
import 'dart:typed_data';
import 'package:encrypt/encrypt.dart' as encrypt;
import '../utils/constants.dart';

class EncryptionService {
  final _key = encrypt.Key.fromUtf8(AppConstants.encryptionKey);
  final _iv = encrypt.IV.fromLength(16);

  Future<void> encryptFile(String inputPath, String outputPath) async {
    final bytes = await File(inputPath).readAsBytes();
    final encrypter = encrypt.Encrypter(encrypt.AES(_key));
    final encrypted = encrypter.encryptBytes(bytes, iv: _iv);
    await File(outputPath).writeAsBytes(encrypted.bytes);
    // Delete original file
    await File(inputPath).delete();
  }

  Future<Uint8List> decryptFile(String path) async {
    final bytes = await File(path).readAsBytes();
    final encrypter = encrypt.Encrypter(encrypt.AES(_key));
    final decrypted = encrypter.decryptBytes(encrypt.Encrypted(bytes), iv: _iv);
    return Uint8List.fromList(decrypted);
  }
}
