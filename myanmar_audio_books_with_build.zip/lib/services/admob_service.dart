import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../utils/constants.dart';

class AdMobService {
  RewardedAd? _rewardedAd;

  void loadRewardedAd(Function() onAdLoaded) {
    RewardedAd.load(
      adUnitId: AppConstants.adMobRewardId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          _rewardedAd = ad;
          onAdLoaded();
        },
        onAdFailedToLoad: (error) {
          print('RewardedAd failed to load: \$error');
        },
      ),
    );
  }

  void showRewardedAd(Function() onUserEarnedReward) {
    if (_rewardedAd != null) {
      _rewardedAd!.show(
        onUserEarnedReward: (ad, reward) {
          onUserEarnedReward();
          _rewardedAd = null;
        },
      );
    }
  }
}
