import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/models.dart';

class SupabaseService {
  final _client = Supabase.instance.client;

  Future<List<Author>> getAuthors() async {
    final response = await _client.from('authors').select();
    return (response as List).map((json) => Author.fromJson(json)).toList();
  }

  Future<List<Book>> getBooksByAuthor(String authorId) async {
    final response = await _client
        .from('books')
        .select('*, authors(name)')
        .eq('author_id', authorId);
    return (response as List).map((json) => Book.fromJson(json)).toList();
  }

  Future<List<Book>> searchBooks(String query) async {
    final response = await _client
        .from('books')
        .select('*, authors(name)')
        .ilike('title', '%$query%');
    return (response as List).map((json) => Book.fromJson(json)).toList();
  }
}
