import 'package:flutter/material.dart';
import 'package:audio_video_progress_bar/audio_video_progress_bar.dart';
import 'package:just_audio/just_audio.dart';
import '../models/models.dart';
import '../services/audio_player_service.dart';

class PlayerScreen extends StatefulWidget {
  final Book book;
  final bool isOffline;

  PlayerScreen({required this.book, this.isOffline = false});

  @override
  _PlayerScreenState createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  final AudioPlayerService _playerService = AudioPlayerService();
  double _speed = 1.0;

  @override
  void initState() {
    super.initState();
    _playerService.playBook(widget.book, isOffline: widget.isOffline);
  }

  @override
  void dispose() {
    _playerService.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.book.title)),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            widget.book.coverUrl != null
                ? Image.network(widget.book.coverUrl!, height: 250)
                : Icon(Icons.music_note, size: 200, color: Colors.grey),
            SizedBox(height: 30),
            Text(widget.book.title, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            Text(widget.book.authorName, style: TextStyle(fontSize: 16, color: Colors.grey)),
            SizedBox(height: 30),
            StreamBuilder<Duration?>(
              stream: _playerService.player.positionStream,
              builder: (context, snapshot) {
                final position = snapshot.data ?? Duration.zero;
                return ProgressBar(
                  progress: position,
                  total: _playerService.player.duration ?? Duration.zero,
                  onSeek: (duration) => _playerService.seek(duration),
                );
              },
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                IconButton(
                  icon: Icon(Icons.replay_15),
                  onPressed: () => _playerService.seek(_playerService.player.position - Duration(seconds: 15)),
                ),
                StreamBuilder<PlayerState>(
                  stream: _playerService.player.playerStateStream,
                  builder: (context, snapshot) {
                    final playerState = snapshot.data;
                    final processingState = playerState?.processingState;
                    final playing = playerState?.playing;
                    if (processingState == ProcessingState.loading || processingState == ProcessingState.buffering) {
                      return CircularProgressIndicator();
                    } else if (playing != true) {
                      return IconButton(icon: Icon(Icons.play_arrow, size: 64), onPressed: _playerService.player.play);
                    } else if (processingState != ProcessingState.completed) {
                      return IconButton(icon: Icon(Icons.pause, size: 64), onPressed: _playerService.player.pause);
                    } else {
                      return IconButton(icon: Icon(Icons.replay, size: 64), onPressed: () => _playerService.seek(Duration.zero));
                    }
                  },
                ),
                IconButton(
                  icon: Icon(Icons.forward_15),
                  onPressed: () => _playerService.seek(_playerService.player.position + Duration(seconds: 15)),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('Speed: '),
                DropdownButton<double>(
                  value: _speed,
                  items: [0.75, 1.0, 1.25, 1.5, 2.0].map((s) => DropdownMenuItem(value: s, child: Text('\${s}x'))).toList(),
                  onChanged: (val) {
                    if (val != null) {
                      setState(() => _speed = val);
                      _playerService.setSpeed(val);
                    }
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
