import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_provider.dart';
import '../widgets/book_list_item.dart';

class DownloadsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Downloads')),
      body: Consumer<AppProvider>(
        builder: (context, provider, child) {
          if (provider.downloadedBooks.isEmpty) {
            return Center(child: Text('No offline items yet.'));
          }
          return ListView.builder(
            itemCount: provider.downloadedBooks.length,
            itemBuilder: (context, index) => BookListItem(
              book: provider.downloadedBooks[index],
              isOffline: true,
            ),
          );
        },
      ),
    );
  }
}
