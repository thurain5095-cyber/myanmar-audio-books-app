import 'package:flutter/material.dart';
import '../models/models.dart';
import '../services/supabase_service.dart';
import '../widgets/book_list_item.dart';

class AuthorBooksScreen extends StatefulWidget {
  final Author author;
  AuthorBooksScreen({required this.author});

  @override
  _AuthorBooksScreenState createState() => _AuthorBooksScreenState();
}

class _AuthorBooksScreenState extends State<AuthorBooksScreen> {
  final SupabaseService _supabaseService = SupabaseService();
  List<Book> _books = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadBooks();
  }

  Future<void> _loadBooks() async {
    final books = await _supabaseService.getBooksByAuthor(widget.author.id);
    setState(() {
      _books = books;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.author.name)),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: _books.length,
              itemBuilder: (context, index) => BookListItem(book: _books[index]),
            ),
    );
  }
}
