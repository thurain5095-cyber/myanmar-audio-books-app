import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_provider.dart';

class SettingsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<AppProvider>(context);
    
    return Scaffold(
      appBar: AppBar(title: Text('Settings')),
      body: ListView(
        children: [
          SwitchListTile(
            title: Text('Dark Mode'),
            secondary: Icon(Icons.brightness_6),
            value: provider.isDarkMode,
            onChanged: (val) => provider.toggleDarkMode(),
          ),
          ListTile(
            title: Text('Clear Cache'),
            leading: Icon(Icons.delete_sweep),
            onTap: () {
              // Logic to clear cache
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Cache cleared')));
            },
          ),
          ListTile(
            title: Text('Privacy Policy'),
            leading: Icon(Icons.privacy_tip),
            onTap: () {
              showAboutDialog(
                context: context,
                applicationName: 'မြန်မာစာပေဟောပြောပွဲများ',
                applicationVersion: '1.0.0',
                children: [Text('Your privacy is our priority. No personal data is collected.')],
              );
            },
          ),
        ],
      ),
    );
  }
}
