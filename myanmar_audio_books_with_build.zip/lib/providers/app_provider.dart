import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/models.dart';
import '../services/supabase_service.dart';
import '../services/download_service.dart';

class AppProvider with ChangeNotifier {
  final SupabaseService _supabaseService = SupabaseService();
  final DownloadService _downloadService = DownloadService();
  
  List<Author> authors = [];
  List<Book> downloadedBooks = [];
  bool isDarkMode = false;
  bool isLoading = false;

  AppProvider() {
    _loadSettings();
    fetchAuthors();
    _loadDownloadedBooks();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    isDarkMode = prefs.getBool('isDarkMode') ?? false;
    notifyListeners();
  }

  Future<void> toggleDarkMode() async {
    isDarkMode = !isDarkMode;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isDarkMode', isDarkMode);
    notifyListeners();
  }

  Future<void> fetchAuthors() async {
    isLoading = true;
    notifyListeners();
    try {
      authors = await _supabaseService.getAuthors();
    } catch (e) {
      print('Error fetching authors: \$e');
    }
    isLoading = false;
    notifyListeners();
  }

  Future<void> _loadDownloadedBooks() async {
    // In a real app, you'd store metadata in SQLite or SharedPreferences
    // For simplicity, we'll check the local directory
    // This is a placeholder for actual local storage logic
  }

  Future<void> refreshDownloads() async {
    // Logic to refresh the list of downloaded files
    notifyListeners();
  }
}
