class AppConstants {
  static const String supabaseUrl = 'https://eemcuzdwzmndwaoliseg.supabase.co';
  static const String supabaseAnonKey = 'sb_publishable_AE4XbALuLg8yD_ot8ZtlQQ_7W_y6vzE';

  // Google Test IDs for Ads
  static const String adMobRewardId = 'ca-app-pub-3940256099942544/5224354917';
  
  // Encryption Key (In production, this should be stored securely)
  static const String encryptionKey = 'myanmar-audio-books-secure-key-32'; // 32 chars
}
