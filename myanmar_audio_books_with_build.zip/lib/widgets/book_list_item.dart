import 'package:flutter/material.dart';
import '../models/models.dart';
import '../services/admob_service.dart';
import '../services/download_service.dart';
import '../screens/player_screen.dart';

class BookListItem extends StatefulWidget {
  final Book book;
  final bool isOffline;

  BookListItem({required this.book, this.isOffline = false});

  @override
  _BookListItemState createState() => _BookListItemState();
}

class _BookListItemState extends State<BookListItem> {
  final AdMobService _adMobService = AdMobService();
  final DownloadService _downloadService = DownloadService();
  bool _isDownloading = false;
  double _progress = 0;
  bool _alreadyDownloaded = false;

  @override
  void initState() {
    super.initState();
    _checkStatus();
  }

  void _checkStatus() async {
    final status = await _downloadService.isDownloaded(widget.book.id);
    if (mounted) setState(() => _alreadyDownloaded = status);
  }

  void _startDownload() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Watch Ad to Download'),
        content: Text('Please watch a short video to download this audio book for offline use.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _adMobService.loadRewardedAd(() {
                _adMobService.showRewardedAd(() async {
                  setState(() => _isDownloading = true);
                  final path = await _downloadService.downloadAndEncrypt(
                    widget.book,
                    (p) => setState(() => _progress = p),
                  );
                  setState(() {
                    _isDownloading = false;
                    if (path != null) {
                      _alreadyDownloaded = true;
                      widget.book.localPath = path;
                    }
                  });
                });
              });
            },
            child: Text('Watch Ad'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(Icons.audiotrack, color: Colors.blue),
      title: Text(widget.book.title),
      subtitle: Text(widget.book.authorName),
      trailing: _isDownloading
          ? SizedBox(
              width: 24,
              height: 24,
              child: CircularProgressIndicator(value: _progress, strokeWidth: 2),
            )
          : IconButton(
              icon: Icon(_alreadyDownloaded ? Icons.check_circle : Icons.download_for_offline,
                  color: _alreadyDownloaded ? Colors.green : null),
              onPressed: _alreadyDownloaded ? null : _startDownload,
            ),
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => PlayerScreen(book: widget.book, isOffline: widget.isOffline || _alreadyDownloaded),
        ),
      ),
    );
  }
}
